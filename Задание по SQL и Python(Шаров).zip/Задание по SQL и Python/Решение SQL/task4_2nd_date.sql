SELECT id, date_from
FROM newtable 
WHERE (id, date_from) IN 
	--Забираем минимальную дау второго по рангу для каждого id
    (SELECT id, MIN(date_from) AS second_highest_date
     FROM 
         (SELECT id, date_from,
         --Присваиваем ранг сортированным по дате значениям и пишем  в новый столбец
                 DENSE_RANK() OVER (PARTITION BY id ORDER BY date_from DESC) AS date_rank
          FROM newtable ) ranked_dates
     WHERE date_rank = 2
     GROUP BY id)