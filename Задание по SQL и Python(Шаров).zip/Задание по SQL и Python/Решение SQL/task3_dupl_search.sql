-- Выбираем поле айди и считаем кол-во его дубликатов в новый столбец
SELECT id, COUNT(*) AS duplicate_count
FROM newtable 
GROUP BY id
HAVING COUNT(*) > 1;


