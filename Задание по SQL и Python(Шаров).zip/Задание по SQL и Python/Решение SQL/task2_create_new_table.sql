CREATE OR REPLACE FUNCTION transform_and_copy_data()
RETURNS VOID AS '
BEGIN
-- Если существует хоть одна запись - удаляем, иначе - создаём таблицу:

  IF EXISTS (SELECT 1 FROM newtable)
  THEN
    DELETE FROM newtable;
  ELSE
    CREATE TABLE newtable (
      id INTEGER,
      date_from DATE,
      t_number TEXT,
      status TEXT
    );
  END IF;
-- Выбираем столбцы и вставляем в новую таблицу данные, меняя тип:

  INSERT INTO newtable (id, date_from, t_number, status)
  SELECT CAST(id AS INTEGER), CAST(date_from AS DATE), CAST(t_number AS TEXT), CAST(status AS TEXT)
  FROM dataset;
END;
'

LANGUAGE plpgsql;


SELECT transform_and_copy_data();

