SELECT 
    id,
    date_from,
    t_number,
    status,
    -- Извлекаем последний символ, сравниваемся с ним и записываем результат канкатенции в новый столбец
    CASE RIGHT(t_number, 1)
        WHEN '1' THEN CONCAT('ID ', id, ' – Брестская область – 1 – ', status)
        WHEN '2' THEN CONCAT('ID ', id, ' – Витебская область – 2 – ', status)
        WHEN '3' THEN CONCAT('ID ', id, ' – Гомельская область – 3 – ', status)
        WHEN '4' THEN CONCAT('ID ', id, ' – Гродненская область – 4 – ', status)
        WHEN '5' THEN CONCAT('ID ', id, ' – Минская область – 5 – ', status)
        WHEN '6' THEN CONCAT('ID ', id, ' – Могилёвская область – 6 – ', status)
        WHEN '7' THEN CONCAT('ID ', id, ' – Минск – 7 – ', status)
    END AS region_status_info
FROM newtable;