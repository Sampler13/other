# Поскольку структура XML файла  не позволяет парсить его с помощью xml.etree.ElementTree,
# будем использовать стандартные инструменты

import pandas as pd

with open('task_python.XML') as file:
    lines = file.readlines()

# Формируем список и избавляесся от лишних символов
formated_lines = [x.translate({ord(c): None for c in '\t\n<>/"'}) for x in lines][1:-2]

result_dict = {}
current_line = None

# Создаём словарь где ключ - это лайн, значение - подсловарь
for item in formated_lines:
    if 'line=' in item:
        current_line = item
        result_dict[current_line] = {}
    elif item == 'line':
        continue
    else:
        key, value = item.split('=')
        result_dict[current_line][key] = value

# Формируем Датафрейм и грузим его в CSV ( меняем запятую на точку, избегая конфликта разделителей)
df = pd.DataFrame(result_dict).transpose()
df = df.replace(',', '.', regex=True)
df.to_csv('output.csv', index=False)

print('Файл успешно создан!')
